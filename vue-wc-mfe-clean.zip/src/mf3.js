import './tailwind.css'
import { defineCustomElement } from 'vue'
import Comp from './components/TodoSummary.ce.vue'

const el = defineCustomElement(Comp)
if (!customElements.get('mf-todo-summary')) {
  customElements.define('mf-todo-summary', el)
}
