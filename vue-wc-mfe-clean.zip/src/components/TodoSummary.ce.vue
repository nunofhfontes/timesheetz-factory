<script setup>
defineProps({
  total: Number,
  done: Number
})
</script>

<template>
  <div class="p-4 border rounded-lg">
    <p>Total: {{ total }}</p>
    <p>Done: {{ done }}</p>
  </div>
</template>
