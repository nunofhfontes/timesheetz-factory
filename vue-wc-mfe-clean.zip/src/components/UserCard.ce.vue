<script setup>
defineProps({
  name: String,
  role: String
})
</script>

<template>
  <div class="p-4 border rounded-lg shadow bg-white">
    <h2 class="text-lg font-bold">{{ name }}</h2>
    <p class="text-gray-500">{{ role }}</p>
  </div>
</template>
