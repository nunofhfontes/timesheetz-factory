<script setup>
import { ref } from 'vue'
const props = defineProps({ start: Number })
const count = ref(props.start || 0)
</script>

<template>
  <div class="p-4 border rounded-lg">
    <p class="mb-2">Count: {{ count }}</p>
    <button class="px-3 py-1 bg-blue-500 text-white rounded" @click="count++">
      Increment
    </button>
  </div>
</template>
