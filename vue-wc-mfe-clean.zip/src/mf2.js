import './tailwind.css'
import { defineCustomElement } from 'vue'
import Comp from './components/CounterBox.ce.vue'

const el = defineCustomElement(Comp)
if (!customElements.get('mf-counter-box')) {
  customElements.define('mf-counter-box', el)
}
