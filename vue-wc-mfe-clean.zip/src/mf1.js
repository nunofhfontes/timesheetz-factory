import './tailwind.css'
import { defineCustomElement } from 'vue'
import Comp from './components/UserCard.ce.vue'

const el = defineCustomElement(Comp)
if (!customElements.get('mf-user-card')) {
  customElements.define('mf-user-card', el)
}
