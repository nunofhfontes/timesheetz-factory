export default {
  content: ["./src/**/*.{js,vue,html}"],
  theme: { extend: {} },
  plugins: [],
}
