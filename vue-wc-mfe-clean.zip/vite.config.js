import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

const externalVue = process.env.VITE_EXTERNAL_VUE === 'true'

export default defineConfig({
  plugins: [vue({ customElement: true })],
  build: {
    lib: {
      entry: {
        mf1: resolve(__dirname, 'src/mf1.js'),
        mf2: resolve(__dirname, 'src/mf2.js'),
        mf3: resolve(__dirname, 'src/mf3.js'),
      },
      formats: ['es']
    },
    rollupOptions: {
      external: externalVue ? ['vue'] : [],
      output: {
        entryFileNames: '[name].js'
      }
    }
  }
})
