# Vue dual mode with .ce.vue wrappers

This project supports:

1. Native Vue app mode
2. Web components mode with separate entry files:
   - `mf1.js`
   - `mf2.js`
   - `mf3.js`

## Main idea

- `src/components/*.vue` are the normal app components
- `src/wc/*.ce.vue` are custom-element wrappers
- each `.ce.vue` file imports Tailwind through its own `<style>` block
- Vue injects those styles into the component Shadow DOM automatically during the custom-element build

## Install

```bash
npm install
```

## Run native app

```bash
npm run dev
```

## Build native app

```bash
npm run build:app
```

Output:
```bash
dist-app
```

## Build web components with bundled Vue

```bash
npm run build:wc
```

Output:
```bash
dist-wc
```

## Build web components with external Vue

```bash
npm run build:wc:external-vue
```

Output:
```bash
dist-wc-external-vue
```
