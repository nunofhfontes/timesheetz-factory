import { defineCustomElement } from 'vue'
import CounterBoxElement from './CounterBox.ce.vue'

const Element = defineCustomElement(CounterBoxElement)

if (!customElements.get('mf-counter-box')) {
  customElements.define('mf-counter-box', Element)
}
