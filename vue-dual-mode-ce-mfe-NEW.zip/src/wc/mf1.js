import { defineCustomElement } from 'vue'
import UserCardElement from './UserCard.ce.vue'

const Element = defineCustomElement(UserCardElement)

if (!customElements.get('mf-user-card')) {
  customElements.define('mf-user-card', Element)
}
