<script setup>
import TodoSummary from '../components/TodoSummary.vue'

defineOptions({
  inheritAttrs: false
})
</script>

<template>
  <TodoSummary v-bind="$attrs" />
</template>

<style>
@import '../styles.css';
:host {
  display: block;
}
</style>
