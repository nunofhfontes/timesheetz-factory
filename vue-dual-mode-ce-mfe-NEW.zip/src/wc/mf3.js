import { defineCustomElement } from 'vue'
import TodoSummaryElement from './TodoSummary.ce.vue'

const Element = defineCustomElement(TodoSummaryElement)

if (!customElements.get('mf-todo-summary')) {
  customElements.define('mf-todo-summary', Element)
}
