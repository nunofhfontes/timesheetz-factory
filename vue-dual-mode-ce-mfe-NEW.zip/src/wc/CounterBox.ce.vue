<script setup>
import CounterBox from '../components/CounterBox.vue'

defineOptions({
  inheritAttrs: false
})
</script>

<template>
  <CounterBox v-bind="$attrs" />
</template>

<style>
@import '../styles.css';
:host {
  display: block;
}
</style>
