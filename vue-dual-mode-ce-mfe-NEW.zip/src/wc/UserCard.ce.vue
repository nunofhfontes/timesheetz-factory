<script setup>
import UserCard from '../components/UserCard.vue'

defineOptions({
  inheritAttrs: false
})
</script>

<template>
  <UserCard v-bind="$attrs" />
</template>

<style>
@import '../styles.css';
:host {
  display: block;
}
</style>
