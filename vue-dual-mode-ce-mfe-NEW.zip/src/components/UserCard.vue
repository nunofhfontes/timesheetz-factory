<script setup>
defineProps({
  name: { type: String, default: 'John Doe' },
  role: { type: String, default: 'Frontend Engineer' },
  team: { type: String, default: 'Core UI' },
  status: { type: String, default: 'online' }
})
</script>

<template>
  <article class="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
    <div class="flex items-start justify-between gap-4">
      <div>
        <h2 class="text-xl font-bold text-slate-900">{{ name }}</h2>
        <p class="mt-1 text-sm text-slate-500">{{ role }}</p>
      </div>
      <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700">{{ status }}</span>
    </div>

    <div class="mt-5 rounded-xl bg-slate-50 p-4">
      <p class="text-xs uppercase tracking-wide text-slate-500">Team</p>
      <p class="mt-1 text-sm font-medium text-slate-800">{{ team }}</p>
    </div>
  </article>
</template>
