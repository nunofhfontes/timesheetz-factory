import '../styles.css'
import { defineCustomElement } from 'vue'

export function registerElement(tagName, component) {
  const Element = defineCustomElement(component, { shadowRoot: false })

  if (!customElements.get(tagName)) {
    customElements.define(tagName, Element)
  }
}
