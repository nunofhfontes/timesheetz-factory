import TodoSummary from '../components/TodoSummary.vue'
import { registerElement } from './register'
registerElement('mf-todo-summary', TodoSummary)
