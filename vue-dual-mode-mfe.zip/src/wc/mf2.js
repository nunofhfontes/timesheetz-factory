import CounterBox from '../components/CounterBox.vue'
import { registerElement } from './register'
registerElement('mf-counter-box', CounterBox)
