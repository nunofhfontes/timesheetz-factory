import UserCard from '../components/UserCard.vue'
import { registerElement } from './register'
registerElement('mf-user-card', UserCard)
