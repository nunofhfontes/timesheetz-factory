# Vue dual mode example

This project supports two modes from the same codebase:

1. Native Vue app mode
2. Web components mode with three separate entry files

## Install

npm install

## Run native app

npm run dev

## Build native app

npm run build:app

## Build web components with bundled Vue

npm run build:wc

## Build web components with external Vue

npm run build:wc:external-vue
