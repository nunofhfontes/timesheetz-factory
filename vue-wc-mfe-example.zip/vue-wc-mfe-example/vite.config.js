import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'node:path'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const externalVue = env.VITE_EXTERNAL_VUE === 'true'

  return {
    plugins: [vue({ customElement: true })],
    build: {
      outDir: externalVue ? 'dist-external-vue' : 'dist',
      emptyOutDir: true,
      cssCodeSplit: false,
      rollupOptions: {
        input: {
          mf1: resolve(__dirname, 'src/mf1.js'),
          mf2: resolve(__dirname, 'src/mf2.js'),
          mf3: resolve(__dirname, 'src/mf3.js'),
          registerAll: resolve(__dirname, 'src/register-all.js')
        },
        external: externalVue ? ['vue'] : [],
        output: {
          format: 'es',
          entryFileNames: '[name].js'
        }
      }
    }
  }
})
