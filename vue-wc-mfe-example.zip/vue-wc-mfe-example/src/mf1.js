import './tailwind.css'
import { defineCustomElement } from 'vue'
import UserCard from './components/UserCard.ce.vue'
import { safeDefine } from './register'

const UserCardElement = defineCustomElement(UserCard, {
  shadowRoot: false
})

safeDefine('mf-user-card', UserCardElement)

export { UserCardElement }
