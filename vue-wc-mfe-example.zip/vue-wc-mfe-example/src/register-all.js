import { UserCardElement } from './mf1'
import { CounterBoxElement } from './mf2'
import { TodoSummaryElement } from './mf3'
import { safeDefine } from './register'

export function registerAll() {
  safeDefine('mf-user-card', UserCardElement)
  safeDefine('mf-counter-box', CounterBoxElement)
  safeDefine('mf-todo-summary', TodoSummaryElement)
}
