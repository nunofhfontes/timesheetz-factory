<template>
  <div class="block rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
    <div class="flex items-center justify-between gap-3">
      <div>
        <p class="text-base font-semibold text-slate-900">{{ title }}</p>
        <p class="text-sm text-slate-500">Simple shared-state-like isolated microfrontend widget</p>
      </div>
      <span class="rounded-full bg-sky-100 px-3 py-1 text-xs font-semibold text-sky-700">
        {{ done }}/{{ total }} done
      </span>
    </div>

    <ul class="mt-4 space-y-2">
      <li
        v-for="item in items"
        :key="item.id"
        class="flex items-center gap-3 rounded-xl border border-slate-200 px-3 py-2"
      >
        <input
          :id="`todo-${item.id}`"
          v-model="item.done"
          type="checkbox"
          class="h-4 w-4 rounded border-slate-300"
          @change="emitSummary"
        >
        <label
          :for="`todo-${item.id}`"
          class="text-sm"
          :class="item.done ? 'text-slate-400 line-through' : 'text-slate-700'"
        >
          {{ item.label }}
        </label>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { computed, ref } from 'vue'

const props = defineProps({
  title: { type: String, default: 'Team checklist' },
  tasks: {
    type: String,
    default: 'Design API,Implement UI,Write tests'
  }
})

const emit = defineEmits(['summary'])

const items = ref(
  props.tasks
    .split(',')
    .map((task, index) => ({
      id: index + 1,
      label: task.trim(),
      done: false
    }))
)

const total = computed(() => items.value.length)
const done = computed(() => items.value.filter((item) => item.done).length)

function emitSummary() {
  emit('summary', {
    total: total.value,
    done: done.value,
    pending: total.value - done.value
  })
}
</script>
