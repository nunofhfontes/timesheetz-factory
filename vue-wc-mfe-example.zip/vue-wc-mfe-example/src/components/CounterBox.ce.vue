<template>
  <div class="block rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
    <div class="flex items-center justify-between gap-3">
      <div>
        <p class="text-sm font-medium uppercase tracking-wide text-slate-500">{{ title }}</p>
        <p class="mt-1 text-3xl font-bold text-slate-900">{{ count }}</p>
      </div>
      <span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-700">
        Web Component
      </span>
    </div>

    <div class="mt-4 flex gap-2">
      <button
        type="button"
        class="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white transition hover:opacity-90"
        @click="decrement"
      >
        -1
      </button>
      <button
        type="button"
        class="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white transition hover:opacity-90"
        @click="increment"
      >
        +1
      </button>
      <button
        type="button"
        class="rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
        @click="reset"
      >
        Reset
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, watch } from 'vue'

const props = defineProps({
  title: { type: String, default: 'Counter' },
  start: { type: Number, default: 0 }
})

const emit = defineEmits(['change'])

const count = ref(props.start)

watch(
  () => props.start,
  (value) => {
    count.value = value
  }
)

function notify() {
  emit('change', count.value)
}

function increment() {
  count.value += 1
  notify()
}

function decrement() {
  count.value -= 1
  notify()
}

function reset() {
  count.value = props.start
  notify()
}
</script>
