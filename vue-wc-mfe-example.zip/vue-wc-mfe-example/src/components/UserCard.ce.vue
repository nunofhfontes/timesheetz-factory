<template>
  <div class="block rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
    <div class="flex items-center gap-3">
      <div class="flex h-12 w-12 items-center justify-center rounded-full bg-indigo-100 text-lg font-bold text-indigo-700">
        {{ initials }}
      </div>

      <div class="min-w-0 flex-1">
        <p class="truncate text-base font-semibold text-slate-900">{{ name }}</p>
        <p class="truncate text-sm text-slate-500">{{ role }}</p>
      </div>
    </div>

    <p class="mt-3 text-sm leading-6 text-slate-600">
      {{ bio }}
    </p>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  name: { type: String, default: 'Jane Doe' },
  role: { type: String, default: 'Frontend Engineer' },
  bio: {
    type: String,
    default: 'Reusable profile card exposed as a Vue-powered web component.'
  }
})

const initials = computed(() => {
  return props.name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() || '')
    .join('')
})
</script>
