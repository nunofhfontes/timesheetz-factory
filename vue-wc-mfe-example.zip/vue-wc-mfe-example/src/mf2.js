import './tailwind.css'
import { defineCustomElement } from 'vue'
import CounterBox from './components/CounterBox.ce.vue'
import { safeDefine } from './register'

const CounterBoxElement = defineCustomElement(CounterBox, {
  shadowRoot: false
})

safeDefine('mf-counter-box', CounterBoxElement)

export { CounterBoxElement }
