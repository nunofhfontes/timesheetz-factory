import './tailwind.css'
import { defineCustomElement } from 'vue'
import TodoSummary from './components/TodoSummary.ce.vue'
import { safeDefine } from './register'

const TodoSummaryElement = defineCustomElement(TodoSummary, {
  shadowRoot: false
})

safeDefine('mf-todo-summary', TodoSummaryElement)

export { TodoSummaryElement }
