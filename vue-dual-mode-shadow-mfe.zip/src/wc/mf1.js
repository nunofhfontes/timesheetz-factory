import { defineCustomElement } from 'vue'
import cssText from '../styles.css?inline'
import UserCard from '../components/UserCard.vue'

const BaseElement = defineCustomElement(UserCard)

class MfUserCardElement extends BaseElement {
  constructor() {
    super()
    this.injectTailwind()
  }

  injectTailwind() {
    if (!this.shadowRoot) return
    if (this.shadowRoot.querySelector('style[data-mf-tailwind]')) return

    const style = document.createElement('style')
    style.setAttribute('data-mf-tailwind', 'true')
    style.textContent = cssText
    this.shadowRoot.prepend(style)
  }
}

if (!customElements.get('mf-user-card')) {
  customElements.define('mf-user-card', MfUserCardElement)
}
