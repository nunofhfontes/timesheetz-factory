import { defineCustomElement } from 'vue'
import cssText from '../styles.css?inline'
import TodoSummary from '../components/TodoSummary.vue'

const BaseElement = defineCustomElement(TodoSummary)

class MfTodoSummaryElement extends BaseElement {
  constructor() {
    super()
    this.injectTailwind()
  }

  injectTailwind() {
    if (!this.shadowRoot) return
    if (this.shadowRoot.querySelector('style[data-mf-tailwind]')) return

    const style = document.createElement('style')
    style.setAttribute('data-mf-tailwind', 'true')
    style.textContent = cssText
    this.shadowRoot.prepend(style)
  }
}

if (!customElements.get('mf-todo-summary')) {
  customElements.define('mf-todo-summary', MfTodoSummaryElement)
}
