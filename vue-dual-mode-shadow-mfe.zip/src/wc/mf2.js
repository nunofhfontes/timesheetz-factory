import { defineCustomElement } from 'vue'
import cssText from '../styles.css?inline'
import CounterBox from '../components/CounterBox.vue'

const BaseElement = defineCustomElement(CounterBox)

class MfCounterBoxElement extends BaseElement {
  constructor() {
    super()
    this.injectTailwind()
  }

  injectTailwind() {
    if (!this.shadowRoot) return
    if (this.shadowRoot.querySelector('style[data-mf-tailwind]')) return

    const style = document.createElement('style')
    style.setAttribute('data-mf-tailwind', 'true')
    style.textContent = cssText
    this.shadowRoot.prepend(style)
  }
}

if (!customElements.get('mf-counter-box')) {
  customElements.define('mf-counter-box', MfCounterBoxElement)
}
