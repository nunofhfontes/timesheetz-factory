<script setup>
import { computed } from 'vue'

const props = defineProps({
  total: { type: Number, default: 0 },
  done: { type: Number, default: 0 },
  title: { type: String, default: 'Todo summary' }
})

const progress = computed(() => {
  if (!props.total) return 0
  return Math.min(100, Math.round((props.done / props.total) * 100))
})
</script>

<template>
  <article class="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
    <p class="text-sm font-semibold uppercase tracking-wide text-indigo-600">{{ title }}</p>
    <div class="mt-4 flex items-end justify-between">
      <div>
        <p class="text-3xl font-bold text-slate-900">{{ done }}/{{ total }}</p>
        <p class="mt-1 text-sm text-slate-500">Tasks completed</p>
      </div>
      <p class="text-lg font-semibold text-slate-700">{{ progress }}%</p>
    </div>
    <div class="mt-4 h-3 overflow-hidden rounded-full bg-slate-100">
      <div class="h-full rounded-full bg-indigo-600" :style="{ width: progress + '%' }"></div>
    </div>
  </article>
</template>
