<script setup>
import { ref } from 'vue'

const props = defineProps({
  start: { type: Number, default: 0 },
  title: { type: String, default: 'Counter box' }
})

const emit = defineEmits(['change'])
const count = ref(props.start)

function increment() {
  count.value += 1
  emit('change', count.value)
}

function decrement() {
  count.value -= 1
  emit('change', count.value)
}
</script>

<template>
  <article class="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
    <p class="text-sm font-semibold uppercase tracking-wide text-indigo-600">{{ title }}</p>
    <p class="mt-4 text-4xl font-bold text-slate-900">{{ count }}</p>

    <div class="mt-5 flex gap-3">
      <button class="rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white" @click="decrement">-1</button>
      <button class="rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white" @click="increment">+1</button>
    </div>
  </article>
</template>
