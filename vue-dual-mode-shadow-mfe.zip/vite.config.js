import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

export default defineConfig(({ mode }) => {
  const isWcBuild = mode === 'wc'
  const externalVue = process.env.VITE_EXTERNAL_VUE === 'true'

  if (isWcBuild) {
    return {
      plugins: [vue({ customElement: true })],
      build: {
        outDir: externalVue ? 'dist-wc-external-vue' : 'dist-wc',
        emptyOutDir: true,
        lib: {
          entry: {
            mf1: resolve(__dirname, 'src/wc/mf1.js'),
            mf2: resolve(__dirname, 'src/wc/mf2.js'),
            mf3: resolve(__dirname, 'src/wc/mf3.js')
          },
          formats: ['es']
        },
        rollupOptions: {
          external: externalVue ? ['vue'] : [],
          output: {
            entryFileNames: '[name].js'
          }
        }
      }
    }
  }

  return {
    plugins: [vue()],
    build: {
      outDir: 'dist-app',
      emptyOutDir: true
    }
  }
})
