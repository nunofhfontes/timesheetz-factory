# Vue dual mode example with shadow DOM Tailwind

This version keeps the dual-mode setup and changes two things:

1. No shared register.js
2. Each web component injects Tailwind CSS into its own shadow root

## Install

```bash
npm install
```

## Run native app

```bash
npm run dev
```

## Build native app

```bash
npm run build:app
```

## Build web components with bundled Vue

```bash
npm run build:wc
```

## Build web components with external Vue

```bash
npm run build:wc:external-vue
```
