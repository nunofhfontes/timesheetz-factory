<script setup>
import UserCard from './components/UserCard.vue'
import CounterBox from './components/CounterBox.vue'
import TodoSummary from './components/TodoSummary.vue'
</script>

<template>
  <main class="min-h-screen bg-slate-100 p-8">
    <div class="mx-auto max-w-6xl">
      <header class="mb-8 rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
        <p class="mb-2 text-sm font-semibold uppercase tracking-wide text-indigo-600">Dual mode example</p>
        <h1 class="text-3xl font-bold text-slate-900">Native Vue app + plain JS web components</h1>
        <p class="mt-3 text-slate-600">
          The app uses normal Vue SFCs. The web-component export layer uses plain JavaScript with defineComponent() and h(),
          so the WC build outputs exactly mf1.js, mf2.js and mf3.js.
        </p>
      </header>

      <section class="grid gap-6 md:grid-cols-3">
        <UserCard name="Jane Cooper" role="Frontend Architect" team="Platform" status="online" />
        <CounterBox :start="3" title="Native app counter" />
        <TodoSummary :total="12" :done="8" title="Sprint progress" />
      </section>
    </div>
  </main>
</template>
