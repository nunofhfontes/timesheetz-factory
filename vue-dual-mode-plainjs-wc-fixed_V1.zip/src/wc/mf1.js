import { defineCustomElement, defineComponent, h } from 'vue'

const cssText = `
:host{display:block}
*,::before,::after{box-sizing:border-box;border:0 solid #e5e7eb}
article,div,p,h2,button,span{margin:0;padding:0}
.rounded-2xl{border-radius:1rem}.rounded-xl{border-radius:.75rem}.rounded-full{border-radius:9999px}
.bg-white{background-color:rgb(255 255 255)}.bg-slate-50{background-color:rgb(248 250 252)}.bg-slate-100{background-color:rgb(241 245 249)}
.text-slate-900{color:rgb(15 23 42)}.text-slate-800{color:rgb(30 41 59)}.text-slate-700{color:rgb(51 65 85)}.text-slate-500{color:rgb(100 116 139)}
.text-xs{font-size:.75rem;line-height:1rem}.text-sm{font-size:.875rem;line-height:1.25rem}.text-xl{font-size:1.25rem;line-height:1.75rem}
.font-medium{font-weight:500}.font-bold{font-weight:700}.uppercase{text-transform:uppercase}.tracking-wide{letter-spacing:.025em}
.p-4{padding:1rem}.p-6{padding:1.5rem}.px-3{padding-left:.75rem;padding-right:.75rem}.py-1{padding-top:.25rem;padding-bottom:.25rem}
.mt-1{margin-top:.25rem}.mt-5{margin-top:1.25rem}.gap-4{gap:1rem}.flex{display:flex}.items-start{align-items:flex-start}.justify-between{justify-content:space-between}
.shadow-sm{box-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05)}.ring-1{box-shadow:0 0 0 1px rgb(226 232 240)}
`

const Component = defineComponent({
  props: {
    name: { type: String, default: 'John Doe' },
    role: { type: String, default: 'Frontend Engineer' },
    team: { type: String, default: 'Core UI' },
    status: { type: String, default: 'online' }
  },
  setup(props) {
    return () => h('article', { class: 'rounded-2xl bg-white p-6 shadow-sm ring-1' }, [
      h('div', { class: 'flex items-start justify-between gap-4' }, [
        h('div', null, [
          h('h2', { class: 'text-xl font-bold text-slate-900' }, props.name),
          h('p', { class: 'mt-1 text-sm text-slate-500' }, props.role)
        ]),
        h('span', { class: 'rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-700' }, props.status)
      ]),
      h('div', { class: 'mt-5 rounded-xl bg-slate-50 p-4' }, [
        h('p', { class: 'text-xs uppercase tracking-wide text-slate-500' }, 'Team'),
        h('p', { class: 'mt-1 text-sm font-medium text-slate-800' }, props.team)
      ])
    ])
  }
})

const Element = defineCustomElement(Component, { styles: [cssText] })
if (!customElements.get('mf-user-card')) customElements.define('mf-user-card', Element)
