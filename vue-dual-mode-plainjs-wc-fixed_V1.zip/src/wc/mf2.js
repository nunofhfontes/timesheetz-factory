import { defineCustomElement, defineComponent, h, ref } from 'vue'

const cssText = `
:host{display:block}
*,::before,::after{box-sizing:border-box;border:0 solid #e5e7eb}
article,div,p,button{margin:0;padding:0}button{font:inherit;cursor:pointer}
.rounded-2xl{border-radius:1rem}.rounded-xl{border-radius:.75rem}
.bg-white{background-color:rgb(255 255 255)}.bg-slate-900{background-color:rgb(15 23 42)}.bg-indigo-600{background-color:rgb(79 70 229)}
.text-white{color:rgb(255 255 255)}.text-slate-900{color:rgb(15 23 42)}.text-slate-700{color:rgb(51 65 85)}.text-indigo-600{color:rgb(79 70 229)}
.text-sm{font-size:.875rem;line-height:1.25rem}.text-4xl{font-size:2.25rem;line-height:2.5rem}
.font-medium{font-weight:500}.font-semibold{font-weight:600}.font-bold{font-weight:700}.uppercase{text-transform:uppercase}.tracking-wide{letter-spacing:.025em}
.p-6{padding:1.5rem}.px-4{padding-left:1rem;padding-right:1rem}.py-2{padding-top:.5rem;padding-bottom:.5rem}
.mt-4{margin-top:1rem}.mt-5{margin-top:1.25rem}.gap-3{gap:.75rem}.flex{display:flex}
.shadow-sm{box-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05)}.ring-1{box-shadow:0 0 0 1px rgb(226 232 240)}.border{border-width:1px}.border-slate-300{border-color:rgb(203 213 225)}
`

const Component = defineComponent({
  props: {
    start: { type: Number, default: 0 },
    title: { type: String, default: 'Counter box' }
  },
  emits: ['change'],
  setup(props, { emit }) {
    const count = ref(Number(props.start || 0))
    const update = (value) => { count.value = value; emit('change', value) }
    return () => h('article', { class: 'rounded-2xl bg-white p-6 shadow-sm ring-1' }, [
      h('p', { class: 'text-sm font-semibold uppercase tracking-wide text-indigo-600' }, props.title),
      h('p', { class: 'mt-4 text-4xl font-bold text-slate-900' }, String(count.value)),
      h('div', { class: 'mt-5 flex gap-3' }, [
        h('button', { class: 'rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white', onClick: () => update(count.value - 1) }, '-1'),
        h('button', { class: 'rounded-xl bg-indigo-600 px-4 py-2 text-sm font-medium text-white', onClick: () => update(count.value + 1) }, '+1'),
        h('button', { class: 'rounded-xl border border-slate-300 px-4 py-2 text-sm font-medium text-slate-700', onClick: () => update(Number(props.start || 0)) }, 'Reset')
      ])
    ])
  }
})

const Element = defineCustomElement(Component, { styles: [cssText] })
if (!customElements.get('mf-counter-box')) customElements.define('mf-counter-box', Element)
