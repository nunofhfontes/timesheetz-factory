import { defineCustomElement, defineComponent, h, computed } from 'vue'

const cssText = `
:host{display:block}
*,::before,::after{box-sizing:border-box;border:0 solid #e5e7eb}
article,div,p{margin:0;padding:0}
.rounded-2xl{border-radius:1rem}.rounded-full{border-radius:9999px}
.bg-white{background-color:rgb(255 255 255)}.bg-slate-100{background-color:rgb(241 245 249)}.bg-indigo-600{background-color:rgb(79 70 229)}
.text-slate-900{color:rgb(15 23 42)}.text-slate-700{color:rgb(51 65 85)}.text-slate-500{color:rgb(100 116 139)}.text-indigo-600{color:rgb(79 70 229)}
.text-sm{font-size:.875rem;line-height:1.25rem}.text-lg{font-size:1.125rem;line-height:1.75rem}.text-3xl{font-size:1.875rem;line-height:2.25rem}
.font-semibold{font-weight:600}.font-bold{font-weight:700}.uppercase{text-transform:uppercase}.tracking-wide{letter-spacing:.025em}
.p-6{padding:1.5rem}.mt-1{margin-top:.25rem}.mt-4{margin-top:1rem}.flex{display:flex}.items-end{align-items:flex-end}.justify-between{justify-content:space-between}.overflow-hidden{overflow:hidden}.h-3{height:.75rem}
.shadow-sm{box-shadow:0 1px 2px 0 rgb(0 0 0 / 0.05)}.ring-1{box-shadow:0 0 0 1px rgb(226 232 240)}
`

const Component = defineComponent({
  props: {
    total: { type: Number, default: 0 },
    done: { type: Number, default: 0 },
    title: { type: String, default: 'Todo summary' }
  },
  setup(props) {
    const progress = computed(() => {
      const total = Number(props.total || 0)
      const done = Number(props.done || 0)
      if (!total) return 0
      return Math.min(100, Math.round((done / total) * 100))
    })
    return () => h('article', { class: 'rounded-2xl bg-white p-6 shadow-sm ring-1' }, [
      h('p', { class: 'text-sm font-semibold uppercase tracking-wide text-indigo-600' }, props.title),
      h('div', { class: 'mt-4 flex items-end justify-between' }, [
        h('div', null, [
          h('p', { class: 'text-3xl font-bold text-slate-900' }, `${props.done}/${props.total}`),
          h('p', { class: 'mt-1 text-sm text-slate-500' }, 'Tasks completed')
        ]),
        h('p', { class: 'text-lg font-semibold text-slate-700' }, `${progress.value}%`)
      ]),
      h('div', { class: 'mt-4 h-3 overflow-hidden rounded-full bg-slate-100' }, [
        h('div', { class: 'h-3 rounded-full bg-indigo-600', style: { width: `${progress.value}%` } })
      ])
    ])
  }
})

const Element = defineCustomElement(Component, { styles: [cssText] })
if (!customElements.get('mf-todo-summary')) customElements.define('mf-todo-summary', Element)
