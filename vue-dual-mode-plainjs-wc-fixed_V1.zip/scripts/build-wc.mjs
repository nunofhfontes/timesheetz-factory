import { build } from 'vite'
import path from 'node:path'
import fs from 'node:fs'

const root = process.cwd()
const externalVue = process.env.VITE_EXTERNAL_VUE === 'true'
const outDir = path.resolve(root, externalVue ? 'dist-wc-external-vue' : 'dist-wc')

const entries = [
  { name: 'mf1', file: path.resolve(root, 'src/wc/mf1.js') },
  { name: 'mf2', file: path.resolve(root, 'src/wc/mf2.js') },
  { name: 'mf3', file: path.resolve(root, 'src/wc/mf3.js') }
]

fs.rmSync(outDir, { recursive: true, force: true })
fs.mkdirSync(outDir, { recursive: true })

for (const entry of entries) {
  await build({
    configFile: false,
    resolve: externalVue ? {} : {
      alias: {
        vue: 'vue/dist/vue.esm-browser.prod.js'
      }
    },
    define: {
      'process.env.NODE_ENV': JSON.stringify('production'),
      'process.env': '{}',
      '__VUE_OPTIONS_API__': 'true',
      '__VUE_PROD_DEVTOOLS__': 'false',
      '__VUE_PROD_HYDRATION_MISMATCH_DETAILS__': 'false'
    },
    build: {
      emptyOutDir: false,
      outDir,
      minify: true,
      target: 'es2018',
      lib: {
        entry: entry.file,
        formats: ['es'],
        fileName: () => `${entry.name}.js`
      },
      rollupOptions: {
        external: externalVue ? ['vue'] : [],
        output: {
          inlineDynamicImports: true
        }
      }
    }
  })
}
