# Vue dual mode with plain JS web-component export layer

This version follows the exact approach you asked for:

- no `.vue` files in the web-component export layer
- each exported web component is defined in plain `.js`
- uses `defineComponent()` and `h()`
- avoids Vue SFC compilation in the WC layer
- build output is exactly:
  - `mf1.js`
  - `mf2.js`
  - `mf3.js`

## Fix included

The bundled WC build now aliases Vue to the browser production ESM build:

- `vue/dist/vue.esm-browser.prod.js`

This avoids the browser error:

- `Uncaught ReferenceError: process is not defined`

That error happens when the bundler pulls in a Vue build that still expects Node-style `process.env` checks at runtime.

## Structure

- `src/components/*.vue` -> normal Vue app components
- `src/wc/*.js` -> standalone web-component entry files in plain JS
- `scripts/build-wc.mjs` -> builds each entry separately so no shared helper chunk is emitted

## Commands

```bash
npm install
npm run dev
npm run build:app
npm run build:wc
npm run build:wc:external-vue
```
